/*
 * FILE: services/engine/browser-extension/bg.js   (extension background service worker)
 * WHAT IT DOES: relays what content.js / the popup need to and from the FundHub engine on this computer
 *   (`engine capture-server`, http://127.0.0.1:4477): page captures, documents, the work list ("queue"),
 *   progress numbers, a company's status. It also handles the "open next company" shortcut (Alt+Shift+N):
 *   one keypress = you ask for the next company, it opens in the current LBR tab. Talks ONLY to 127.0.0.1.
 *   Search sweep: "open next search" (button or Alt+Shift+S) opens the next planned LBR search in the current tab,
 *   ONE search per click — exactly what typing it in LBR's search box does. Nothing runs on a timer.
 */
const ENGINE = "http://127.0.0.1:4477";
const SEARCH = (term) => "https://www.lbr.lu/mjrcs-web-front/consult-search-list?search=" + encodeURIComponent(term);
const COMPANY = (rcs) => "https://www.lbr.lu/mjrcs-web-front/consult-company/" + encodeURIComponent(rcs) + "?tab=deposit";

async function call(path, body) {
  const res = await fetch(ENGINE + path, body ? { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) } : {});
  return res.json();
}

/** Opens a URL in the active tab if it is an LBR tab, otherwise in a new tab. */
async function openLbr(url) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab && /^https:\/\/www\.lbr\.lu\//.test(tab.url || "")) await chrome.tabs.update(tab.id, { url });
  else await chrome.tabs.create({ url });
}
const openCompany = (rcs) => openLbr(COMPANY(rcs));

/** Opens the search of one sweep word (its results list). Remembered for the panel. */
async function openSweepItem(item) {
  await chrome.storage.local.set({ lastSweepOpen: { term: item.term, at: Date.now() } });
  await openLbr(SEARCH(item.term));
}

/** Badge: documents saved in this browser session. */
let docs = 0;
const badge = () => {
  chrome.action.setBadgeBackgroundColor({ color: "#0b2a4a" });
  chrome.action.setBadgeText({ text: docs ? String(docs) : "" });
};

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  (async () => {
    try {
      switch (msg.type) {
        case "capture":
          return reply(await call("/capture", msg.payload));
        case "document": {
          const r = await call("/document", msg.payload);
          if (r.ok) {
            docs++;
            badge();
          }
          return reply(r);
        }
        case "filings":
          return reply(await call("/filings?rcs=" + encodeURIComponent(msg.rcs)));
        case "next":
          return reply(await call("/next"));
        case "queue":
          return reply(await call(`/queue?n=${msg.n || 10}&filter=${encodeURIComponent(msg.filter || "")}`));
        case "stats":
          return reply(await call("/stats"));
        case "company":
          return reply(await call("/company?rcs=" + encodeURIComponent(msg.rcs)));
        case "skip":
          return reply(await call("/skip", { rcs: msg.rcs }));
        // Capture rounds ("loops"): status, register, control.
        case "round":
          return reply(await call("/round"));
        case "rounds":
          return reply(await call("/rounds"));
        case "round-start":
          return reply(await call("/round/start", msg.options));
        case "round-close":
          return reply(await call("/round/close", {}));
        case "round-reset":
          return reply(await call("/round/reset-skipped", {}));
        // LBR search sweep.
        case "sweep":
          return reply(await call("/sweep?n=" + (msg.n || 6)));
        case "sweep-plan":
          return reply(await call("/sweep/plan", {}));
        case "sweep-skip":
          return reply(await call("/sweep/skip", { term: msg.term }));
        case "sweep-reset":
          return reply(await call("/sweep/reset-skipped", {}));
        case "open-sweep":
          await openSweepItem(msg.item);
          return reply({ ok: true });
        case "open":
          await openCompany(msg.rcs);
          return reply({ ok: true });
        default:
          return reply({ ok: false, error: "unknown message" });
      }
    } catch (err) {
      reply({ ok: false, error: "FundHub engine not reachable (" + err.message + ")" });
    }
  })();
  return true; // async reply
});

// Alt+Shift+N: open the next company of the work list (respecting the popup's filter).
chrome.commands.onCommand.addListener(async (command) => {
  if (command === "open-next-search") {
    // Alt+Shift+S: the next search of the sweep (one keypress = one search).
    try {
      const r = await call("/sweep?n=1");
      if (r.next && r.next[0]) await openSweepItem(r.next[0]);
    } catch (_) {}
    return;
  }
  if (command !== "open-next") return;
  try {
    const { filter } = await chrome.storage.local.get({ filter: "" });
    const r = await call(`/queue?n=1&filter=${encodeURIComponent(filter)}`);
    if (r.items && r.items[0]) await openCompany(r.items[0].rcs);
  } catch (_) {
    /* engine not running: the popup shows it */
  }
});
